//
//  UIView+Rect.h
//  gywangluo
//
//  Created by yuan on 14/10/30.
//  Copyright (c) 2014年 euc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Custom)
+ (UIImage *)imageWithColor:(UIColor *)color;
@end
