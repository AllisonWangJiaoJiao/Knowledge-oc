//
//  TDAlertView.h
//  TTD
//
//  Created by Yuan on 15/11/9.
//  Copyright © 2015年 EUC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TDAlertView : NSObject

+(TDAlertView *)sharedAlertView;




@end
