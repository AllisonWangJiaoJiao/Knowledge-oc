//
//  NotificationMacroDefine.h
//  ZZFramework_MVC
//
//  Created by 袁亮 on 16/10/18.
//  Copyright © 2016年 Migic_Z. All rights reserved.
//

#ifndef NotificationMacroDefine_h
#define NotificationMacroDefine_h


#define LoginSuccessNotification @"LoginSuccessNotification"
#define LoginOutNotification @"LoginOutNotification"

#endif /* NotificationMacroDefine_h */
